#define BUILD_NUMBER "74"
#define BUILD_DATE "07 ��� 2003 - 15:51:17"
