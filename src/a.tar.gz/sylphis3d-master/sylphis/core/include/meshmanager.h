/***************************************************************************
                          meshmanager.h  -  description
                             -------------------
    begin                : Wed Oct 16 2002
    copyright            : (C) 2002 by Harry Kalogirou
    email                : harkal@gmx.net
 ***************************************************************************/

#ifndef MESHMANAGER_H
#define MESHMANAGER_H

#include <enginecomponent.h>
#include <resourcemanager.h>

class CMeshManager : public CEngineComponent, public CResourceManager {
public:

};

#endif
