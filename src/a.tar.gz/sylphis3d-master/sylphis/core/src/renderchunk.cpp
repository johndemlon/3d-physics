
/***************************************************************************
                        renderchunk.cpp  -  description
                             -------------------
    begin                : Sun Aug 29 2004
    copyright            : (C) 2004 by Harry Kalogirou
    email                : harkal@sylphis3d.com
 ***************************************************************************/


#include <renderchunk.h>

CRenderChunk::CRenderChunk(){

}

CRenderChunk::~CRenderChunk(){

}


