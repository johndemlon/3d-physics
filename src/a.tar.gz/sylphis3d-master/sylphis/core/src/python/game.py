import sys, sylphis
from string import *
from simpleactor import *

class CGame(CSimpleActor):
    def __init__(self, *args):
        CSimpleActor.__init__(self, *args)
      
    def join(self, ent):
        pass
    
    def update(self, timeDelta):
        pass
