import sys, sylphis
from string import *
from simpleactor import *

class CMissile(CSimpleActor):
    def __init__(self, *args):
        CSimpleActor.__init__(self, *args)

    
