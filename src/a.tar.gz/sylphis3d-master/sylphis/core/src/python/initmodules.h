#ifndef _INITMODULES_H
#define _INITMODULES_H

#ifdef __cplusplus
extern "C" {
#endif

void init_sylphis();

#ifdef __cplusplus
}
#endif

#endif
